#/bin/bash

CODE_NAME="strict"
OUT_DIR="builds"
SOURCE="/var/www/codi/"

echo -e "Code: $CODE_NAME"
echo -e "Output path: $OUT_DIR/$CODE_NAME\n"

echo -e "Delete $OUT_DIR/$CODE_NAME\n"
sudo rm -rf $OUT_DIR/$CODE_NAME

echo -e "Create $OUT_DIR\n"
sudo mkdir -p $OUT_DIR

echo -e "Copy from $SOURCE to $OUT_DIR/$CODE_NAME, Please wait ...\n"
sudo cp -a $SOURCE $OUT_DIR/$CODE_NAME

echo -e "Copy from $CODE_NAME to $OUT_DIR/$CODE_NAME, Please wait ...\n"
sudo cp -a $CODE_NAME/ $OUT_DIR/

echo -e "Change owner of $OUT_DIR/$CODE_NAME to $USER:$USER\n"
sudo chown -R $USER:$USER $OUT_DIR/$CODE_NAME

echo -e "\nDeleting [vendor]"
sudo rm -rf $OUT_DIR/$CODE_NAME/vendor
[ ! -d "./$OUT_DIR/$CODE_NAME/vendor" ] && echo -e "Directory /$OUT_DIR/$CODE_NAME/vendor Deleted." || echo -e "Directory /$OUT_DIR/$CODE_NAME/vendor NOT Deleted."

echo -e "\nDeleting [node_modules]"
sudo rm -rf $OUT_DIR/$CODE_NAME/node_modules
[ ! -d "./$OUT_DIR/$CODE_NAME/node_modules" ] && echo -e "Directory /$OUT_DIR/$CODE_NAME/node_modules Deleted." || echo -e "Directory /$OUT_DIR/$CODE_NAME/node_modules NOT Deleted."

echo -e "\nRun Phpstorm"
phpstorm ./$OUT_DIR/$CODE_NAME &

echo -e "\n\n[$CODE_NAME] Generated At [$OUT_DIR/$CODE_NAME] Successfully\n"